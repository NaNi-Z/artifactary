package main

import (
	"fmt"
	"net"
	"os/exec"

	"github.com/charmbracelet/bubbles/help"
	"github.com/charmbracelet/bubbles/key"
	"github.com/charmbracelet/bubbles/textinput"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

type keyMapSelect struct {
	Up       key.Binding
	Down     key.Binding
	Continue key.Binding
	Quit     key.Binding
	Skip     key.Binding
	Select   key.Binding
}

type keyMapConfig struct {
	Confirm key.Binding
	Back    key.Binding
	Next    key.Binding
	Prev    key.Binding
}

var keys = keyMapSelect{
	Up: key.NewBinding(
		key.WithKeys("up"),
		key.WithHelp("↑", "move up"),
	),
	Down: key.NewBinding(
		key.WithKeys("down"),
		key.WithHelp("↓", "move down"),
	),
	Continue: key.NewBinding(
		key.WithKeys("c"),
		key.WithHelp("c", "continue"),
	),
	Quit: key.NewBinding(
		key.WithKeys("q", "esc", "ctrl+c"),
		key.WithHelp("q", "quit and config next time"),
	),
	Skip: key.NewBinding(
		key.WithKeys("s"),
		key.WithHelp("s", "skip forever"),
	),
	Select: key.NewBinding(
		key.WithKeys(" ", "enter"),
		key.WithHelp("space", "select"),
	),
}

var keys_config = keyMapConfig{
	Confirm: key.NewBinding(
		key.WithKeys("enter"),
		key.WithHelp("enter", "confirm and setup network"),
	),
	Back: key.NewBinding(
		key.WithKeys("ctrl+b"),
		key.WithHelp("ctrl+b", "back to select"),
	),
	Next: key.NewBinding(
		key.WithKeys("tab"),
		key.WithHelp("tab", "next input"),
	),
	Prev: key.NewBinding(
		key.WithKeys("shift+tab"),
		key.WithHelp("shift+tab", "prev input"),
	),
}

func (k keyMapSelect) ShortHelp() []key.Binding {
	return []key.Binding{k.Up, k.Down, k.Select, k.Continue, k.Quit, k.Skip}
}

func (k keyMapSelect) FullHelp() [][]key.Binding {
	return [][]key.Binding{
		{k.Up, k.Down, k.Select, k.Continue, k.Quit, k.Skip},
	}
}

func (k keyMapConfig) ShortHelp() []key.Binding {
	return []key.Binding{k.Confirm, k.Back, k.Next, k.Prev}
}

func (k keyMapConfig) FullHelp() [][]key.Binding {
	return [][]key.Binding{
		{k.Confirm, k.Back, k.Next, k.Prev},
	}
}

type netif_mod struct {
	netif   net.Interface
	checked bool
}

type model struct {
	netif_mods    []netif_mod
	keys          keyMapSelect
	keys_config   keyMapConfig
	inputs        []textinput.Model
	help          help.Model
	focused       int
	choice        int
	selected_done bool
	err           error
}

const (
	ip = iota
	gw
	hotPink  = lipgloss.Color("#FF06B7")
	darkGray = lipgloss.Color("#767676")
)

var (
	inputStyle = lipgloss.NewStyle().Foreground(hotPink)
)

func newModel() model {
	var inputs []textinput.Model = make([]textinput.Model, 2)
	inputs[ip] = textinput.New()
	inputs[ip].Placeholder = "xxx.xxx.xxx.xxx/xx"
	inputs[ip].Focus()
	inputs[ip].CharLimit = 18
	inputs[ip].Width = 30
	inputs[ip].Prompt = ""

	inputs[gw] = textinput.New()
	inputs[gw].Placeholder = "xxx.xxx.xxx.xxx"
	inputs[gw].CharLimit = 15
	inputs[gw].Width = 20
	inputs[gw].Prompt = ""
	return model{
		keys:        keys,
		keys_config: keys_config,
		help:        help.New(),
		inputs:      inputs,
		focused:     0,
		err:         nil,
	}
}

func ipaddrValidate(ip string) error {
	return nil
}

func gatewayValidate(ip string) error {
	return nil
}

func main() {
	var (
		netifs []net.Interface

		err error
	)
	models := newModel()
	if netifs, err = net.Interfaces(); err != nil {
		panic(fmt.Sprintf("failed to get interfaces: %v", err))
	}
	for _, netif := range netifs {
		models.netif_mods = append(models.netif_mods, netif_mod{netif: netif})
	}
	tea.LogToFile("debug.log", "debug")
	if _, err := tea.NewProgram(&models, tea.WithAltScreen()).Run(); err != nil {
		panic(fmt.Sprintf("failed to run program: %v", err))
	}
}

func (m *model) Init() tea.Cmd {
	return textinput.Blink
}

func (m *model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	if m.selected_done {
		var cmds []tea.Cmd = make([]tea.Cmd, len(m.inputs))

		switch msg := msg.(type) {
		case tea.KeyMsg:
			switch msg.Type {
			case tea.KeyEnter:
				if m.focused == len(m.inputs)-1 {
					cmd := exec.Command("/bin/bash", "-c", fmt.Sprintf("echo %s > /tmp/ip", m.inputs[ip].Value()))
					err := cmd.Run()
					m.err = err
					return m, nil
				}
				m.nextInput()
			case tea.KeyCtrlC:
				return m, tea.Quit
			case tea.KeyCtrlB:
				m.selected_done = false
			case tea.KeyShiftTab:
				m.prevInput()
			case tea.KeyTab:
				m.nextInput()
			}
			for i := range m.inputs {
				m.inputs[i].Blur()
			}
			m.inputs[m.focused].Focus()

		// We handle errors just like any other message
		case error:
			m.err = msg
			return m, nil
		}

		for i := range m.inputs {
			m.inputs[i], cmds[i] = m.inputs[i].Update(msg)
		}
		return m, tea.Batch(cmds...)
	} else {
		switch typed := msg.(type) {
		case tea.KeyMsg:
			return m, m.handleKeyMsg(typed)
		}
		return m, nil
	}
}

func (m *model) handleKeyMsg(msg tea.KeyMsg) tea.Cmd {
	switch msg.String() {
	case "q", "esc", "ctrl+c":
		return tea.Quit
	case " ", "enter":
		m.netif_mods[m.choice].checked = !m.netif_mods[m.choice].checked
	case "up":
		if m.choice > 0 {
			m.choice--
		}
	case "down":
		if m.choice+1 < len(m.netif_mods) {
			m.choice++
		}
	case "c":
		m.selected_done = true
	case "s":
		return tea.Quit
	}
	return nil
}

func (m *model) View() string {
	m.help.ShowAll = true
	if m.selected_done {
		helpView := m.help.View(m.keys_config)
		errs := ""
		if m.err != nil {
			errs = m.err.Error()
		}
		return fmt.Sprintf(
			` 
	 %s
	 %s
	 %s
	 %s

	 %s
	`,
			inputStyle.Width(30).Render("IP address(CIDR)"),
			m.inputs[ip].View(),
			inputStyle.Width(30).Render("Gateway"),
			m.inputs[gw].View(),
			errs,
		) + "\n" + helpView
	} else {
		curnet := -1
		curnet = m.choice
		helpView := m.help.View(m.keys)
		return m.renderList("choose one or two network interfaces.", m.netif_mods, curnet) + helpView
	}
}

func (m *model) renderList(header string, items []netif_mod, selected int) string {
	out := "~ " + header + "\n"
	for i, item := range items {
		sel := " "
		if i == selected {
			sel = ">"
		}
		check := " "
		if items[i].checked {
			check = "✓"
		}
		addrs, _ := item.netif.Addrs()
		hardaddr := "--:--:--:--:--:--"
		if item.netif.HardwareAddr.String() != "" {
			hardaddr = item.netif.HardwareAddr.String()
		}
		out += fmt.Sprintf("%s [%s] %s\t%s\t%s\t\n", sel, check, item.netif.Name, hardaddr, addrs)
	}
	return out
}

func (m *model) nextInput() {
	m.focused = (m.focused + 1) % len(m.inputs)
}

// prevInput focuses the previous input field
func (m *model) prevInput() {
	m.focused--
	// Wrap around
	if m.focused < 0 {
		m.focused = len(m.inputs) - 1
	}
}
