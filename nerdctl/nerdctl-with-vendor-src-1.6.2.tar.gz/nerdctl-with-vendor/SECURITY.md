See https://github.com/containerd/project/blob/main/SECURITY.md for reporting a vulnerability.
